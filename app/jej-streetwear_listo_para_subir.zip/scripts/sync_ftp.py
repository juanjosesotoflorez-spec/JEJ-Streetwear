import os
import ftplib

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FTP_HOST = 'ftpupload.net'
FTP_USER = 'if0_43187236'
FTP_PASS = '5oYSqtAAPtyXiew'

def sync():
    ftp = ftplib.FTP(FTP_HOST, FTP_USER, FTP_PASS, timeout=25)
    print("FTP connected!", flush=True)

    # 1. Base files
    remote_htdocs = 'jejstreetwear.iblogger.org/htdocs'
    ftp.cwd(remote_htdocs)

    def upload_one(local_rel, remote_dir, remote_name):
        local_full = os.path.join(BASE_DIR, local_rel.replace('/', os.sep))
        ftp.cwd('/' + remote_htdocs + '/' + remote_dir)
        with open(local_full, 'rb') as f:
            print(f"Uploading {local_rel} -> {remote_name}...", flush=True)
            ftp.storbinary(f"STOR {remote_name}", f)

    upload_one('index.html', '', 'index.html')
    upload_one('setup_tables.php', '', 'setup_tables.php')
    upload_one('pages/catalogo.php', 'pages', 'catalogo.php')
    upload_one('includes/funciones.php', 'includes', 'funciones.php')
    upload_one('assets/css/style.css', 'assets/css', 'style.css')
    upload_one('database/jej_streetwear_hosting.sql', 'database', 'jej_streetwear_hosting.sql')

    # 2. Upload images by category
    subfolders = ['camisetas', 'sudaderas', 'pantalones', 'zapatillas', 'chaquetas', 'accesorios']
    total_imgs = 0
    for sub in subfolders:
        local_sub = os.path.join(BASE_DIR, 'assets', 'img', 'products', sub)
        remote_sub_path = f"assets/img/products/{sub}"
        for fname in os.listdir(local_sub):
            local_file = os.path.join(local_sub, fname)
            if os.path.isfile(local_file):
                upload_one(f"assets/img/products/{sub}/{fname}", remote_sub_path, fname)
                total_imgs += 1

    ftp.quit()
    print(f"\nSUCCESS! Uploaded base files and {total_imgs} Jordan product images!", flush=True)

if __name__ == '__main__':
    sync()
