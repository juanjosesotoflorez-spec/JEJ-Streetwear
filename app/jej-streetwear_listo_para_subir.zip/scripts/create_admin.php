<?php
require_once __DIR__ . '/../config/db.php';

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
fwrite(STDOUT, "Correo del administrador: ");
$email = trim((string) fgets(STDIN));
fwrite(STDOUT, "Nombre: ");
$name = trim((string) fgets(STDIN));
fwrite(STDOUT, "Contraseña (mínimo 10 caracteres): ");
if (strncasecmp(PHP_OS, 'WIN', 3) === 0) {
    $password = trim((string) fgets(STDIN));
} else {
    system('stty -echo');
    $password = trim((string) fgets(STDIN));
    system('stty echo');
    fwrite(STDOUT, PHP_EOL);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($name) < 3 || strlen($password) < 10) {
    fwrite(STDERR, "Datos inválidos. No se creó el administrador.\n");
    exit(1);
}
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $mysqli->prepare("INSERT INTO usuarios (nombre, correo, password_hash, rol) VALUES (?, ?, ?, 'admin')");
$stmt->bind_param('sss', $name, $email, $hash);
$stmt->execute();
fwrite(STDOUT, "Administrador creado. Guarda la contraseña de forma segura.\n");
