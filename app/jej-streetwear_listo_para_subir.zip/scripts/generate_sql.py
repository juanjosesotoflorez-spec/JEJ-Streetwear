import os
import json

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATALOG_PATH = os.path.join(BASE_DIR, 'scripts', 'catalog_data.json')

with open(CATALOG_PATH, 'r', encoding='utf-8') as f:
    products = json.load(f)

def escape_sql(val):
    if val is None:
        return 'NULL'
    return "'" + str(val).replace("'", "''") + "'"

def generate_sql(is_local=False):
    lines = []
    lines.append("-- =====================================================================")
    if is_local:
        lines.append("-- JEJ-STREETWEAR: Base de datos para Entorno Local (XAMPP)")
        lines.append("-- =====================================================================")
        lines.append("CREATE DATABASE IF NOT EXISTS jej_streetwear CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
        lines.append("USE jej_streetwear;\n")
    else:
        lines.append("-- JEJ-STREETWEAR: Base de datos para Hosting Remoto (InfinityFree / cPanel)")
        lines.append("-- NOTA: Sin 'CREATE DATABASE' ni 'USE' para compatibilidad con hosting gratuito.")
        lines.append("-- =====================================================================\n")

    lines.append("""CREATE TABLE IF NOT EXISTS usuarios (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  correo VARCHAR(190) NOT NULL UNIQUE,
  telefono VARCHAR(30) NULL,
  password_hash VARCHAR(255) NOT NULL,
  rol ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categorias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL UNIQUE,
  activa TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS productos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  categoria_id INT UNSIGNED NOT NULL,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT NOT NULL,
  precio DECIMAL(12,2) NOT NULL,
  imagen VARCHAR(255) NOT NULL DEFAULT 'assets/img/product-placeholder.svg',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_productos_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  INDEX idx_productos_activo_categoria (activo, categoria_id),
  INDEX idx_productos_nombre (nombre),
  CONSTRAINT chk_producto_precio CHECK (precio >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tallas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(20) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS producto_tallas (
  producto_id BIGINT UNSIGNED NOT NULL,
  talla_id INT UNSIGNED NOT NULL,
  existencias INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (producto_id, talla_id),
  CONSTRAINT fk_producto_tallas_producto FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE,
  CONSTRAINT fk_producto_tallas_talla FOREIGN KEY (talla_id) REFERENCES tallas(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pedidos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id BIGINT UNSIGNED NOT NULL,
  nombre_envio VARCHAR(120) NOT NULL,
  correo_envio VARCHAR(190) NOT NULL,
  telefono_envio VARCHAR(30) NULL,
  direccion VARCHAR(255) NOT NULL,
  ciudad VARCHAR(100) NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  estado ENUM('pendiente','pagado','rechazado','preparando','enviado','cancelado') NOT NULL DEFAULT 'pendiente',
  inventario_descontado TINYINT(1) NOT NULL DEFAULT 0,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  INDEX idx_pedidos_usuario (usuario_id, creado_en)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS detalle_pedido (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id BIGINT UNSIGNED NOT NULL,
  producto_id BIGINT UNSIGNED NOT NULL,
  talla_id INT UNSIGNED NOT NULL,
  nombre_producto VARCHAR(150) NOT NULL,
  nombre_talla VARCHAR(20) NOT NULL,
  cantidad INT UNSIGNED NOT NULL,
  precio_unitario DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_detalle_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  CONSTRAINT fk_detalle_producto FOREIGN KEY (producto_id) REFERENCES productos(id),
  CONSTRAINT fk_detalle_talla FOREIGN KEY (talla_id) REFERENCES tallas(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pagos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id BIGINT UNSIGNED NOT NULL,
  metodo VARCHAR(40) NOT NULL DEFAULT 'simulacion_educativa',
  resultado ENUM('aprobado','rechazado','pendiente') NOT NULL,
  referencia VARCHAR(40) NOT NULL UNIQUE,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pagos_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  INDEX idx_pagos_resultado (resultado, creado_en)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mensajes_contacto (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  correo VARCHAR(190) NOT NULL,
  asunto VARCHAR(160) NOT NULL,
  mensaje TEXT NOT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
""")

    lines.append("-- Categorías oficiales")
    lines.append("INSERT IGNORE INTO categorias (nombre) VALUES")
    lines.append("  ('Camisetas'), ('Sudaderas'), ('Pantalones'), ('Zapatillas'), ('Chaquetas'), ('Accesorios');\n")

    lines.append("-- Tallas oficiales")
    lines.append("INSERT IGNORE INTO tallas (nombre) VALUES")
    lines.append("  ('XS'), ('S'), ('M'), ('L'), ('XL'), ('XXL'), ('Única'), ('38'), ('39'), ('40'), ('41'), ('42'), ('43');\n")

    lines.append("-- Inserción de productos del Catálogo Jordan (si no existen)")
    lines.append("INSERT INTO productos (categoria_id, nombre, descripcion, precio, imagen, activo)")
    selects = []
    for p in products:
        cat = escape_sql(p['categoria'])
        nombre = escape_sql(p['nombre'])
        desc = escape_sql(p['descripcion'])
        precio = p['precio']
        img = escape_sql(p['relative_image'])
        selects.append(f"SELECT {cat} AS categoria, {nombre} AS nombre, {desc} AS descripcion, {precio} AS precio, {img} AS imagen, 1 AS activo")
    
    union_query = "\n  UNION ALL ".join(selects)
    lines.append(f"SELECT c.id, p.nombre, p.descripcion, p.precio, p.imagen, p.activo\nFROM (\n  {union_query}\n) p\nJOIN categorias c ON c.nombre = p.categoria\nWHERE NOT EXISTS (SELECT 1 FROM productos existing WHERE existing.nombre = p.nombre);\n")

    lines.append("-- Actualización de productos existentes (por si ya estaban registrados)")
    lines.append(f"UPDATE productos p\nJOIN (\n  {union_query}\n) p_new ON p.nombre = p_new.nombre\nSET p.descripcion = p_new.descripcion, p.precio = p_new.precio, p.imagen = p_new.imagen, p.activo = 1;\n")

    lines.append("-- Ocultar productos placeholder iniciales para que solo se muestren productos reales")
    lines.append("UPDATE productos SET activo = 0 WHERE imagen LIKE '%placeholder%';\n")

    lines.append("-- Inventario por tallas para los productos Jordan")
    lines.append("""-- 1. Zapatillas: tallas 38 a 43
INSERT IGNORE INTO producto_tallas (producto_id, talla_id, existencias)
SELECT p.id, t.id, 10
FROM productos p
JOIN categorias c ON c.id = p.categoria_id AND c.nombre = 'Zapatillas'
JOIN tallas t ON t.nombre IN ('38', '39', '40', '41', '42', '43');

-- 2. Accesorios: talla Única
INSERT IGNORE INTO producto_tallas (producto_id, talla_id, existencias)
SELECT p.id, t.id, 15
FROM productos p
JOIN categorias c ON c.id = p.categoria_id AND c.nombre = 'Accesorios'
JOIN tallas t ON t.nombre = 'Única';

-- 3. Ropa (Camisetas, Sudaderas, Pantalones, Chaquetas): tallas S, M, L, XL
INSERT IGNORE INTO producto_tallas (producto_id, talla_id, existencias)
SELECT p.id, t.id, 8
FROM productos p
JOIN categorias c ON c.id = p.categoria_id AND c.nombre IN ('Camisetas', 'Sudaderas', 'Pantalones', 'Chaquetas')
JOIN tallas t ON t.nombre IN ('S', 'M', 'L', 'XL');
""")

    lines.append("""-- Cuentas de acceso inicial
INSERT INTO usuarios (id, nombre, correo, password_hash, rol) VALUES
  (1, 'Administrador JEJ', 'admin@jej.com', '$2y$10$LDqB0bJX5ooNZvQ8YJvHSulkQ7LAR0yYPFvlH9bG2oArOxnTWsPey', 'admin'),
  (2, 'Cliente de Prueba', 'cliente@jej.com', '$2y$10$ruKVqHHvpSBKW6SN/VtNLOrJRCNb6RQbmFOtdeAbnJ1VstZuxCH3i', 'cliente')
ON DUPLICATE KEY UPDATE rol = VALUES(rol);
""")

    return "\n".join(lines)

hosting_sql = generate_sql(is_local=False)
with open(os.path.join(BASE_DIR, 'database', 'jej_streetwear_hosting.sql'), 'w', encoding='utf-8') as f:
    f.write(hosting_sql)

local_sql = generate_sql(is_local=True)
with open(os.path.join(BASE_DIR, 'database', 'jej_streetwear.sql'), 'w', encoding='utf-8') as f:
    f.write(local_sql)

print("Generated database/jej_streetwear_hosting.sql and database/jej_streetwear.sql successfully!")
