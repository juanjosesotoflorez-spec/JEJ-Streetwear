import ftplib
import io

check_php = '''<?php
ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/config/db.php';

echo "<h2>Verificando base de datos:</h2>";
$res = $mysqli->query("SHOW TABLES");
if (!$res) {
    die("Error al listar tablas: " . $mysqli->error);
}

$tables = [];
while ($row = $res->fetch_array()) {
    $tables[] = $row[0];
}

echo "<p>Tablas encontradas (" . count($tables) . "): " . implode(', ', $tables) . "</p>";

if (empty($tables)) {
    echo "<h3 style='color:red;'>¡LA BASE DE DATOS ESTA VACIA! No se han creado las tablas.</h3>";
} else {
    // Probar la consulta exacta de catalogo.php
    echo "<h3>Probando consulta de catalogo.php:</h3>";
    try {
        $whereSql = "p.activo = 1";
        $orderSql = "p.id DESC";
        $stmt = $mysqli->prepare("SELECT p.id, p.nombre, p.descripcion, p.precio, p.imagen, c.nombre categoria,
            COALESCE(SUM(pt.existencias), 0) existencias,
            GROUP_CONCAT(DISTINCT IF(pt.existencias > 0, t.nombre, NULL) ORDER BY t.id SEPARATOR ', ') tallas,
            GROUP_CONCAT(DISTINCT IF(pt.existencias > 0, CONCAT(t.id, '|', t.nombre), NULL) ORDER BY t.id SEPARATOR ',') talla_options
            FROM productos p JOIN categorias c ON c.id = p.categoria_id
            LEFT JOIN producto_tallas pt ON pt.producto_id = p.id LEFT JOIN tallas t ON t.id = pt.talla_id
            WHERE $whereSql GROUP BY p.id, c.nombre ORDER BY $orderSql LIMIT ? OFFSET ?");
        $pageSize = 9; $offset = 0;
        $stmt->bind_param('ii', $pageSize, $offset);
        $stmt->execute();
        $prods = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        echo "<p style='color:green;'>Consulta exitosa! Encontrados " . count($prods) . " productos.</p>";
    } catch (Throwable $e) {
        echo "<p style='color:red;'>Error en consulta de catalogo: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
}
'''

ftp = ftplib.FTP('ftpupload.net', 'if0_43187236', '5oYSqtAAPtyXiew', timeout=15)
ftp.cwd('jejstreetwear.iblogger.org/htdocs')
ftp.storbinary('STOR check_error.php', io.BytesIO(check_php.encode('utf-8')))
print('check_error.php UPLOADED!')
ftp.quit()

