import os
import urllib.request
import json
import re

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS_PRODUCTS_DIR = os.path.join(BASE_DIR, 'assets', 'img', 'products')

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
}

products_data = [
    # --- CAMISETAS (6) ---
    {
        'categoria': 'Camisetas',
        'subfolder': 'camisetas',
        'slug': 'camiseta-jordan-brooklyn-sneaker-graphic',
        'nombre': 'Camiseta Jordan Brooklyn Sneaker Graphic',
        'descripcion': 'Camiseta urbana de corte holgado en algodon premium de densidad media con grafico serigrafiado inspirado en la cultura sneaker.',
        'precio': 149900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/e2b61ffd-ea7d-4ce6-91ef-d6547dade6d6/M+J+BRK+SNKR+GFX+SS+CREW.png'
    },
    {
        'categoria': 'Camisetas',
        'subfolder': 'camisetas',
        'slug': 'camiseta-jordan-brooklyn-85-classic',
        'nombre': 'Camiseta Jordan Brooklyn \'85 Classic',
        'descripcion': 'Rinde homenaje a la herencia del 85 con esta camiseta de tejido suave, cuello acanalado y estetica retro de Chicago.',
        'precio': 139900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/4e07d683-f048-4b72-9129-f296ad3de5c5/M+J+BRK+NC+MANEKI+85+SS+CRW.png'
    },
    {
        'categoria': 'Camisetas',
        'subfolder': 'camisetas',
        'slug': 'camiseta-jordan-dri-fit-sport-graphic',
        'nombre': 'Camiseta Jordan Dri-FIT Sport Graphic',
        'descripcion': 'Disenada para entrenar en la cancha o salir a la calle, con tecnologia absorbente de sudor Nike Dri-FIT y ajuste atletico.',
        'precio': 159900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/0d01605b-1366-480d-9905-1ba6dfd30c07/M+J+DF+SPRT+GFX+SS+CREW+3.png'
    },
    {
        'categoria': 'Camisetas',
        'subfolder': 'camisetas',
        'slug': 'camiseta-jordan-dri-fit-performance',
        'nombre': 'Camiseta Jordan Dri-FIT Performance Crew',
        'descripcion': 'Tejido transpirable de secado rapido con corte estandar que brinda frescura durante todo el dia y graficos Jumpman iconicos.',
        'precio': 149900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/0771d05a-38bb-4145-8c3c-2a031345c881/M+J+DF+SPRT+GFX+SS+CREW+4.png'
    },
    {
        'categoria': 'Camisetas',
        'subfolder': 'camisetas',
        'slug': 'camiseta-jordan-fireside-graphic-tee',
        'nombre': 'Camiseta Jordan Fireside Boxy Graphic',
        'descripcion': 'Silueta moderna de corte relajado boxy con estampado audaz en el pecho y tacto ultrasuave para tus outfits diarios.',
        'precio': 139900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/da0f3360-6469-4609-8e83-7fc6f6b5e895/W+J+SS+GF+FRSD+GFX+TEE.png'
    },
    {
        'categoria': 'Camisetas',
        'subfolder': 'camisetas',
        'slug': 'camiseta-manga-larga-jordan-brooklyn-jersey',
        'nombre': 'Camiseta Manga Larga Jordan Brooklyn Jersey',
        'descripcion': 'Camiseta manga larga inspirada en las camisetas de calentamiento de basquetbol, con estampados alusivos a MJ.',
        'precio': 179900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c7ba5024-51f7-4aaf-a20c-c01ce6e21598/W+J+BRK+LS+JRSY+AOP+BC.png'
    },

    # --- SUDADERAS (6) ---
    {
        'categoria': 'Sudaderas',
        'subfolder': 'sudaderas',
        'slug': 'sudadera-jordan-brooklyn-seasonal-fleece',
        'nombre': 'Sudadera Jordan Brooklyn Seasonal Fleece',
        'descripcion': 'Tejido Fleece cepillado de maxima calidez en el interior, bolsillo de canguro y capucha estructurada con cordon de ajuste.',
        'precio': 299900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/42851063-02b2-46f1-b811-dd9932514c3c/M+J+BRK+SSNL+FRSD+FLC+PO.png'
    },
    {
        'categoria': 'Sudaderas',
        'subfolder': 'sudaderas',
        'slug': 'sudadera-capucha-jordan-fireside-hoodie',
        'nombre': 'Sudadera con Capucha Jordan Fireside',
        'descripcion': 'Comodidad de nivel superior con detalles de costuras reforzadas, acabado afelpado y logotipo Jumpman en relieve.',
        'precio': 319900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/780c5842-f17f-4968-80fb-f713ad6c3080/BRK+FIRESIDE+FLC+PO.png'
    },
    {
        'categoria': 'Sudaderas',
        'subfolder': 'sudaderas',
        'slug': 'hoodie-jordan-fierce-fearless',
        'nombre': 'Hoodie Jordan Fierce & Fearless',
        'descripcion': 'Sudadera urbana pesada de corte holgado con diseno tipografico frontal y punos elasticos acanalados de alta durabilidad.',
        'precio': 329900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c0828f4e-ba6c-45ee-8986-140e6774d3c7/FIERCE++FEARLESS+PO+HDY.png'
    },
    {
        'categoria': 'Sudaderas',
        'subfolder': 'sudaderas',
        'slug': 'sudadera-jordan-brooklyn-statement-pullover',
        'nombre': 'Sudadera Jordan Brooklyn Statement Pullover',
        'descripcion': 'Sudadera de edicion Statement confeccionada con tejido French Terry grueso para un look sofisticado y relajado.',
        'precio': 349900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/59f269ff-deb4-4903-8aaf-ba39f6661a6a/M+J+BRK+ST+PO+HD+BB.png'
    },
    {
        'categoria': 'Sudaderas',
        'subfolder': 'sudaderas',
        'slug': 'sudadera-jordan-dri-fit-full-zip-hoops',
        'nombre': 'Sudadera Jordan Dri-FIT Full-Zip Hoops',
        'descripcion': 'Chaqueta/sudadera con cierre completo, tecnologia que absorbe el sudor y bolsillos con cremallera para guardar lo esencial.',
        'precio': 359900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/42dc9711-2640-4b29-ba28-af7376c11b81/M+J+DF+SPRT+HOOP+FLC+FZ+HDY.png'
    },
    {
        'categoria': 'Sudaderas',
        'subfolder': 'sudaderas',
        'slug': 'sudadera-jordan-holiday-all-over-print',
        'nombre': 'Sudadera Jordan Holiday All-Over Print',
        'descripcion': 'Estampado completo con patrones geometricos y simbolos legendarios de Jordan, interior suave y corte espacioso.',
        'precio': 339900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/21293d06-f44c-416c-8656-308703e2532f/JORDAN+HOLIDAY+AOP.png'
    },

    # --- PANTALONES (6) ---
    {
        'categoria': 'Pantalones',
        'subfolder': 'pantalones',
        'slug': 'pantalon-jogger-jordan-brooklyn-fleece',
        'nombre': 'Pantalón Jogger Jordan Brooklyn Fleece Cuffed',
        'descripcion': 'Jogger clasico con punos acanalados en los tobillos, cintura elastica con cordon y bolsillos laterales profundos.',
        'precio': 259900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/04fc1fde-d032-4492-897c-2f818a733598/M+J+BRK+SSNL+FRSD+CUFF+PNT.png'
    },
    {
        'categoria': 'Pantalones',
        'subfolder': 'pantalones',
        'slug': 'pantalon-deportivo-jordan-statement-cuff',
        'nombre': 'Pantalón Deportivo Jordan Statement Cuff',
        'descripcion': 'Silueta conica moderna confeccionada en tejido grueso que mantiene su estructura en cualquier movimiento urbano.',
        'precio': 279900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/61f0cd8a-71d9-4705-95bc-2e7a6c360e4e/M+J+BRK+ST+FLC+CUFF+PANT+BB.png'
    },
    {
        'categoria': 'Pantalones',
        'subfolder': 'pantalones',
        'slug': 'pantalon-jordan-flight-wings-fleece',
        'nombre': 'Pantalón Jordan Flight Wings Fleece',
        'descripcion': 'Inspirado en los miticos trajes de vuelo de Michael Jordan, con paneles ergonomicos y parche tejido Flight.',
        'precio': 289900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/02e225d9-3a7c-4b64-8fc4-e38f30ac1a92/M+J+FLT+WINGS+FLC+PNT.png'
    },
    {
        'categoria': 'Pantalones',
        'subfolder': 'pantalones',
        'slug': 'pantalon-jogger-jordan-brooklyn-classic',
        'nombre': 'Pantalón Jogger Jordan Brooklyn Classic',
        'descripcion': 'La prenda basica definitiva para tu rotacion de streetwear: comodo, resistente y con el logo Jumpman bordado.',
        'precio': 249900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/4ed9d986-aba1-45f0-acda-12a54dafa77c/BROOKLYN+JOGGER.png'
    },
    {
        'categoria': 'Pantalones',
        'subfolder': 'pantalones',
        'slug': 'pantalon-holgado-jordan-flight-91-baggy',
        'nombre': 'Pantalón Holgado Jordan Flight \'91 Baggy',
        'descripcion': 'Corte amplio de estilo noventero con caida fluida en el calzado y cintura elastica regulable.',
        'precio': 299900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/2ccbd618-b55b-415e-b577-24b0aee3ac26/W+J+FLT+91+BGY+PANT+AOP+BC.png'
    },
    {
        'categoria': 'Pantalones',
        'subfolder': 'pantalones',
        'slug': 'pantalon-jordan-relaxed-open-hem-fleece',
        'nombre': 'Pantalón Jordan Relaxed Open-Hem Fleece',
        'descripcion': 'Dobladillo abierto sin elastico en la bota para lucir tus zapatillas favoritas sin interrupciones.',
        'precio': 269900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/e0333064-ffca-4f7c-a3ae-28836d337d69/M+J+BRK+RLT+FLC+OH+PNT.png'
    },

    # --- ZAPATILLAS (6) ---
    {
        'categoria': 'Zapatillas',
        'subfolder': 'zapatillas',
        'slug': 'air-jordan-1-retro-high-og',
        'nombre': 'Air Jordan 1 Retro High OG',
        'descripcion': 'La silueta legendaria que comenzo todo en 1985. Cuero autentico de primera calidad, amortiguacion Air encapsulada y corte alto iconico.',
        'precio': 799900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/3638c536-f339-41db-9533-f1b016df027e/AIR+JORDAN+1+HIGH+OG.png'
    },
    {
        'categoria': 'Zapatillas',
        'subfolder': 'zapatillas',
        'slug': 'air-jordan-12-retro',
        'nombre': 'Air Jordan 12 Retro',
        'descripcion': 'Inspirada en la bandera japonesa del sol naciente, con placa de fibra de carbono completa y unidad Zoom Air ultra reactiva.',
        'precio': 849900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/d02ea3bd-782e-441a-8008-419068be7f01/AIR+JORDAN+12+RETRO.png'
    },
    {
        'categoria': 'Zapatillas',
        'subfolder': 'zapatillas',
        'slug': 'jordan-spizike-low',
        'nombre': 'Jordan Spizike Low',
        'descripcion': 'Homenaje a Spike Lee combinando elementos de los AJ3, AJ4, AJ5 y AJ6 con estampado de elefante y perfil bajo.',
        'precio': 699900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c5da1f47-95b6-4303-995a-1da3a55b6fb0/JORDAN+SPIZIKE+LOW.png'
    },
    {
        'categoria': 'Zapatillas',
        'subfolder': 'zapatillas',
        'slug': 'air-jordan-5-retro-og',
        'nombre': 'Air Jordan 5 Retro OG',
        'descripcion': 'Silueta de los 90 con dientes de tiburon en la entresuela inspirados en aviones de combate de la Segunda Guerra Mundial.',
        'precio': 829900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c08accfa-c1e7-4925-857e-af25a808cb79/AIR+JORDAN+5+RETRO+OG.png'
    },
    {
        'categoria': 'Zapatillas',
        'subfolder': 'zapatillas',
        'slug': 'air-jordan-1-low-se',
        'nombre': 'Air Jordan 1 Low Special Edition',
        'descripcion': 'La version low de corte limpio con combinacion de materiales texturizados y estetica versatil para uso diario.',
        'precio': 599900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/692edac8-3081-4cec-847a-21eccbbab7f8/AIR+JORDAN+1+LOW+SE.png'
    },
    {
        'categoria': 'Zapatillas',
        'subfolder': 'zapatillas',
        'slug': 'air-jordan-9-retro-boot-nrg',
        'nombre': 'Air Jordan 9 Retro Boot NRG',
        'descripcion': 'Construccion todoterreno resistente al agua con suela de traccion agresiva y acabados metalicos premium.',
        'precio': 869900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/4fcaef09-dc8f-4e57-a65b-c22947c840f9/AIR+JORDAN+9+RETRO+BOOT+NRG.png'
    },

    # --- CHAQUETAS (6) ---
    {
        'categoria': 'Chaquetas',
        'subfolder': 'chaquetas',
        'slug': 'chaqueta-jordan-brooklyn-relaxed',
        'nombre': 'Chaqueta Jordan Brooklyn Relaxed Jacket',
        'descripcion': 'Chaqueta ligera con cremallera completa, tejido de tafetan suave repelente al agua y forro interior transpirable.',
        'precio': 389900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/f2d28cbf-7ae3-4c42-ae7c-1145dfbf6d85/M+J+BRK+RLT+JKT.png'
    },
    {
        'categoria': 'Chaquetas',
        'subfolder': 'chaquetas',
        'slug': 'chaqueta-acolchada-jordan-brooklyn-puffer',
        'nombre': 'Chaqueta Acolchada Jordan Brooklyn Puffer',
        'descripcion': 'Aislamiento termico sintetico de alto rendimiento que mantiene el calor sin anadir peso excesivo en climas frios.',
        'precio': 529900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/f3305c4d-d94e-4e77-8837-c735bf2d4a18/W+J+BRK+PUFFER+JKT.png'
    },
    {
        'categoria': 'Chaquetas',
        'subfolder': 'chaquetas',
        'slug': 'chaleco-acolchado-jordan-flight-mountainside',
        'nombre': 'Chaleco Acolchado Jordan Flight Mountainside',
        'descripcion': 'Chaleco versatil para superposicion de capas, con cuello alto protector y multiples bolsillos seguros con cremallera.',
        'precio': 349900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/8f537276-a63b-4f59-8f3b-730b3e7da8e1/M+J+FLT+MTNSIDE+VEST.png'
    },
    {
        'categoria': 'Chaquetas',
        'subfolder': 'chaquetas',
        'slug': 'chaqueta-jordan-brooklyn-chore-laser',
        'nombre': 'Chaqueta Jordan Brooklyn Chore Laser',
        'descripcion': 'Silueta estilo chaqueta de trabajo en loneta resistente con grabado laser de motivos Jumpman iconicos.',
        'precio': 459900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/7b776939-fe4d-4969-95b1-37f562f061fc/M+J+BRK+LSR+CHORE+JKT.png'
    },
    {
        'categoria': 'Chaquetas',
        'subfolder': 'chaquetas',
        'slug': 'chaqueta-cortavientos-jordan-brooklyn-graphic',
        'nombre': 'Chaqueta Cortavientos Jordan Brooklyn Graphic',
        'descripcion': 'Bloqueador de viento con capucha ajustable, elasticos en punos y dobladillo y detalles reflectantes.',
        'precio': 369900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/ec2a628a-6f93-41da-bf75-5945b2d432a4/BROOKLYN+GFX+PUFFER.png'
    },
    {
        'categoria': 'Chaquetas',
        'subfolder': 'chaquetas',
        'slug': 'chaqueta-jordan-sport-jam-retro-warmup',
        'nombre': 'Chaqueta Jordan Sport Jam Retro Warmup',
        'descripcion': 'Inspirada en las chaquetas de calentamiento de los campeonatos de los 90 con franjas en contraste.',
        'precio': 399900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/8c263fb5-4524-4683-ac9e-a85380ab5a3f/M+J+SPRT+JAM+JACKET+SJ.png'
    },

    # --- ACCESORIOS (6) ---
    {
        'categoria': 'Accesorios',
        'subfolder': 'accesorios',
        'slug': 'maletin-deportivo-jordan-collectors-gym-duffel',
        'nombre': 'Maletín Deportivo Jordan Gym Duffel',
        'descripcion': 'Compartimento principal espacioso de facil acceso, bolsillo lateral ventilado para zapatillas y correa acolchada ajustable.',
        'precio': 219900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/54d2fd6e-8075-40cc-b1b1-7939c72d5506/COLLECTORS+GYM+DUFFEL.png'
    },
    {
        'categoria': 'Accesorios',
        'subfolder': 'accesorios',
        'slug': 'mochila-morral-jordan-collectors-daypack',
        'nombre': 'Mochila Morral Jordan Collectors Daypack',
        'descripcion': 'Capacidad optimizada con funda interior acolchada para laptop de hasta 15", bolsillo organizador y espaldar ergonomico.',
        'precio': 249900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/25a3a0c1-baee-4c36-bf90-2f81eb441167/COLLECTORS+DAYPACK.png'
    },
    {
        'categoria': 'Accesorios',
        'subfolder': 'accesorios',
        'slug': 'gorro-jordan-peak-beanie-cuffed',
        'nombre': 'Gorro Jordan Peak Beanie Cuffed',
        'descripcion': 'Tejido de punto acrilico suave de tacto calido con dobladillo vuelto y parche metalico Jumpman en el frente.',
        'precio': 99900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/e5f31571-5f8a-4f3e-b49d-4f3998a2b7b1/U+J+PEAK+BEANIE+FIRE.png'
    },
    {
        'categoria': 'Accesorios',
        'subfolder': 'accesorios',
        'slug': 'guantes-termicos-jordan-fleece-2',
        'nombre': 'Guantes Térmicos Jordan Fleece 2.0',
        'descripcion': 'Confeccionados en fleece termico con tecnologia tactil en la punta de los dedos para usar el smartphone sin quitartelos.',
        'precio': 119900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/4eccf878-e8a6-4190-ad25-79026c907d33/JDN+FLEECE+LG+2.0.png'
    },
    {
        'categoria': 'Accesorios',
        'subfolder': 'accesorios',
        'slug': 'mochila-jordan-real-tree-outdoor-daypack',
        'nombre': 'Mochila Jordan Real Tree Outdoor',
        'descripcion': 'Diseno de camuflaje de alto impacto con cordones elasticos frontales para sujetar chaquetas o accesorios adicionales.',
        'precio': 259900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/252f92bb-bb90-4293-a004-de117aeb7de5/REAL+TREE+DAYPACK.png'
    },
    {
        'categoria': 'Accesorios',
        'subfolder': 'accesorios',
        'slug': 'medias-jordan-everyday-elevated-pack-x6',
        'nombre': 'Medias Jordan Everyday Elevated (Pack x6)',
        'descripcion': 'Seis pares de calcetines con soporte en el arco del pie, amortiguacion estrategica y tejido Dri-FIT antitranspirante.',
        'precio': 109900,
        'image_url': 'https://static.nike.com/a/images/t_web_pw_592_v2/f_jpg/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/9abb5f40-ff69-4ae9-a802-6f04998613ae/U+J+ED+ELVD+CREW+6PR+-+144+JOR.png'
    }
]

print(f"Total products to download: {len(products_data)}")

downloaded_count = 0
for idx, prod in enumerate(products_data, 1):
    subfolder_path = os.path.join(ASSETS_PRODUCTS_DIR, prod['subfolder'])
    os.makedirs(subfolder_path, exist_ok=True)
    
    filename = f"{prod['slug']}.jpg"
    dest_path = os.path.join(subfolder_path, filename)
    relative_path = f"assets/img/products/{prod['subfolder']}/{filename}"
    prod['relative_image'] = relative_path
    
    print(f"[{idx}/{len(products_data)}] Downloading {prod['nombre']}...")
    try:
        req = urllib.request.Request(prod['image_url'], headers=headers)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = resp.read()
            with open(dest_path, 'wb') as f:
                f.write(data)
        downloaded_count += 1
        print(f"   -> OK: {dest_path} ({len(data)} bytes)")
    except Exception as e:
        print(f"   -> ERROR downloading {prod['nombre']}: {e}")

print(f"\nDownloaded {downloaded_count}/{len(products_data)} images successfully!")

# Save catalog JSON metadata for reuse
with open(os.path.join(BASE_DIR, 'scripts', 'catalog_data.json'), 'w', encoding='utf-8') as f:
    json.dump(products_data, f, indent=2, ensure_ascii=False)
print("Catalog data saved to scripts/catalog_data.json")
